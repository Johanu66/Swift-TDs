//
//  CommandView.swift
//  mypizza
//
//  Created by Houénoukpo Johanu Gandonou on 14/01/2025.
//

import Foundation
import SwiftUI

struct NewCommandView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var selectedDough = "Thin Crust"
    let doughs = ["Thin Crust", "Thick Crust", "Gluten Free", "Regular Crust"]
    @State private var selectedRecipe = "Margherita"
    let recipes = ["Margherita", "Pepperoni", "Vegetarian", "BBQ Chicken"]
    
    var body: some View {
        ZStack {
            // Background Image
            Image("pizza")
                .resizable()
                .scaledToFill()
                .frame(width: 100)
                .edgesIgnoringSafeArea(.all)
            
            // Transparent sur le background
            Color.black.opacity(0.4)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                Text("Nouvelle commande")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
                // Email and Password fields
                VStack(spacing: 15) {
                    Text("Choisissez votre recette")
                        .foregroundColor(Color.white)
                    HStack {
                        Picker("Choisissez une recette", selection: $selectedRecipe) {
                            ForEach(recipes, id: \.self) { recipe in
                                Text(recipe)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                        .frame(maxWidth: .infinity)
                    }
                    .padding(8)
                    .background(Color.white.opacity(0.8))
                    .cornerRadius(10)
                    .frame(maxWidth: .infinity)
                    
                    
                    Text("Sélectionnez votre pâte")
                        .foregroundColor(Color.white)
                    HStack {
                        Picker("Type de pâte", selection: $selectedDough) {
                            ForEach(doughs, id: \.self) { dough in
                                Text(dough)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                        .frame(maxWidth: .infinity)
                    }
                    .padding(8)
                    .background(Color.white.opacity(0.8))
                    .cornerRadius(10)
                    .frame(maxWidth: .infinity)
                }
                //.padding(.horizontal, 20)
                
                // Login button
                Button(action: {
                    // Handle login action
                }) {
                    Text("Commander")
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red)
                        .cornerRadius(10)
                }
                //.padding(.horizontal, 20)
                
                // Register prompt
                Button(action: {
                    // Handle create account action
                    dismiss()
                }) {
                    Text("Retour à la liste des commandes")
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red)
                        .cornerRadius(10)
                }
                //.padding(.horizontal, 20)
                .padding(.top, 60)
            }
            .padding(.vertical, 50)
            .background(Color.black.opacity(0.5))
            //.padding(.horizontal, 10)
        }
    }
}


#Preview {
    NewCommandView()
}
