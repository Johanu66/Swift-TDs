//
//  LoginView.swift
//  mypizza
//
//  Created by Houénoukpo Johanu Gandonou on 14/01/2025.
//

import Foundation
import SwiftUI


private let loginURL = "https://mypizza.lesmoulinsdudev.com/auth"


func postData(mail: String, password: String, completion: @escaping (Bool, String) -> Void) {
    // Paramètres à envoyer dans la requête POST
    let params: [String: Any] = [
        "mail": mail,
        "password": password
    ]
    
    if let url = URL(string: loginURL) {
        // Appel de la méthode postRequest
        APIService.shared.postRequest(url: url, params: params, type: TokenData.self, completionHandler: { (response) in
            // Si la requête réussie
            completion(true, "Utilisateur enregistré avec succès!")
        }) { (error) in
            // Si une erreur se produit
            completion(false, "Erreur lors de l'enregistrement : \(error)")
        }
    } else {
        completion(false, "URL invalide")
    }
}


struct LoginView: View {
    @State private var showRegisterView = false
    @State private var showCommandListView = false
    
    @State private var mail = ""
    @State private var password = ""
    @State private var errorMessage = ""
    @State private var isError = false
    @State private var isLoading = false
    
    var body: some View {
        ZStack {
            // Background Image
            Image("pizza")
                .resizable()
                .scaledToFill()
                .frame(width: 200)
                .edgesIgnoringSafeArea(.all)
            
            // Transparent sur le background
            Color.black.opacity(0.4)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                Text("My Pizza !")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
                // Email and Password fields
                VStack(spacing: 15) {
                    TextField("Adresse mail", text: $mail)
                        .padding()
                        .background(Color.white.opacity(0.8))
                        .cornerRadius(10)
                    
                    SecureField("Mot de passe", text: $password)
                        .padding()
                        .background(Color.white.opacity(0.8))
                        .cornerRadius(10)
                }
                //.padding(.horizontal, 20)
                
                // Error message display
                if isError {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .padding()
                }
                
                // Login button
                Button(action: {
                    // Handle login action
                    
                    // Validate fields
                    if mail.isEmpty || password.isEmpty {
                        isError = true
                        errorMessage = "Tous les champs doivent être remplis."
                        return
                    }
                    
                    // Start loading indicator
                    isLoading = true
                    
                    // Call postData to register the user
                    postData(mail: mail, password: password) { success, message in
                        isLoading = false
                        if success {
                            // Handle success (clear form or navigate away)
                            errorMessage = message
                            isError = false
                            showCommandListView = true
                        } else {
                            // Handle error
                            errorMessage = message
                            isError = true
                        }
                    }
                }) {
                    Text("Connexion")
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red)
                        .cornerRadius(10)
                }
                .fullScreenCover(isPresented: $showCommandListView) {
                    CommandListView()
                }
                //.padding(.horizontal, 20)
                
                // Register prompt
                VStack(spacing: 10) {
                    Text("Pas encore de compte?")
                        .foregroundColor(.white)
                    
                    Button(action: {
                        // Handle create account action
                        showRegisterView = true
                    }) {
                        Text("Créer un compte")
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.red)
                            .cornerRadius(10)
                    }
                    .fullScreenCover(isPresented: $showRegisterView) {
                        RegisterView()
                    }
                }
                //.padding(.horizontal, 20)
            }
            .padding(.vertical, 50)
            .background(Color.black.opacity(0.5))
            //.padding(.horizontal, 10)
        }
    }
}


#Preview {
    LoginView()
}
