//
//  UserData.swift
//  mypizza
//
//  Created by Houénoukpo Johanu Gandonou on 14/01/2025.
//

import Foundation

struct RegisterResponseStatus: Codable {
    var status: String
}
