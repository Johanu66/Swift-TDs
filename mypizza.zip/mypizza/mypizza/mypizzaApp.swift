//
//  mypizzaApp.swift
//  mypizza
//
//  Created by Houénoukpo Johanu Gandonou on 14/01/2025.
//

import SwiftUI

@main
struct mypizzaApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}
