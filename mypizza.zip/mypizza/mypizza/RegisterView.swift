//
//  RegisterView.swift
//  mypizza
//
//  Created by Houénoukpo Johanu Gandonou on 14/01/2025.
//

import Foundation
import SwiftUI

private let registerURL = "https://mypizza.lesmoulinsdudev.com/register"


func postData(name: String, mail: String, password: String, completion: @escaping (Bool, String) -> Void) {
    // Paramètres à envoyer dans la requête POST
    let params: [String: Any] = [
        "name": name,
        "mail": mail,
        "password": password
    ]
    
    if let url = URL(string: registerURL) {
        // Appel de la méthode postRequest
        APIService.shared.postRequest(url: url, params: params, type: RegisterResponseStatus.self, completionHandler: { (response) in
            // Si la requête réussie
            completion(true, "Utilisateur enregistré avec succès!")
        }) { (error) in
            // Si une erreur se produit
            completion(false, "Erreur lors de l'enregistrement : \(error)")
        }
    } else {
        completion(false, "URL invalide")
    }
}

struct RegisterView: View {
    @Environment(\.dismiss) private var dismiss
    
    @State private var name = ""
    @State private var mail = ""
    @State private var password = ""
    @State private var errorMessage = ""
    @State private var isError = false
    @State private var isLoading = false
    
    var body: some View {
        ZStack {
            // Background Image
            Image("pizza")
                .resizable()
                .scaledToFill()
                .frame(width: 100)
                .edgesIgnoringSafeArea(.all)
            
            // Transparent overlay on the background
            Color.black.opacity(0.4)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                Text("Inscription")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
                // mail and Password fields
                VStack(spacing: 15) {
                    TextField("Nom", text: $name)
                        .padding()
                        .background(Color.white.opacity(0.8))
                        .cornerRadius(10)
                    
                    TextField("Adresse mail", text: $mail)
                        .padding()
                        .background(Color.white.opacity(0.8))
                        .cornerRadius(10)
                        .keyboardType(.emailAddress)
                        .autocapitalization(.none)
                    
                    SecureField("Mot de passe", text: $password)
                        .padding()
                        .background(Color.white.opacity(0.8))
                        .cornerRadius(10)
                }
                
                // Error message display
                if isError {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .padding()
                }
                
                // Register button
                Button(action: {
                    // Validate fields
                    if name.isEmpty || mail.isEmpty || password.isEmpty {
                        isError = true
                        errorMessage = "Tous les champs doivent être remplis."
                        return
                    }
                    
                    // Start loading indicator
                    isLoading = true
                    
                    // Call postData to register the user
                    postData(name: name, mail: mail, password: password) { success, message in
                        isLoading = false
                        if success {
                            // Handle success (clear form or navigate away)
                            errorMessage = message
                            isError = false
                            dismiss()
                        } else {
                            // Handle error
                            errorMessage = message
                            isError = true
                        }
                    }
                }) {
                    Text("Enregistrer")
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red)
                        .cornerRadius(10)
                }
                
                // Register prompt
                VStack(spacing: 10) {
                    Text("Déjà un compte ?")
                        .foregroundColor(.white)
                    
                    Button(action: {
                        // Navigate back to login page
                        dismiss()
                    }) {
                        Text("Retour à la page de connexion")
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.red)
                            .cornerRadius(10)
                    }
                }
            }
            .padding(.vertical, 50)
            .background(Color.black.opacity(0.5))
        }
        .disabled(isLoading)  // Disable interaction while loading
    }
}

#Preview {
    RegisterView()
}
