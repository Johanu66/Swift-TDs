//
//  ContentView.swift
//  mypizza
//
//  Created by Houénoukpo Johanu Gandonou on 14/01/2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
        }
        .padding()
        .background(Color.black.opacity(0.2))
    }
}

#Preview {
    ContentView()
}
