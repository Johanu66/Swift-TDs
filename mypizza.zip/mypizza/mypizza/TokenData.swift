//
//  TokenData.swift
//  mypizza
//
//  Created by Houénoukpo Johanu Gandonou on 14/01/2025.
//

import Foundation

struct TokenData: Codable {
    var token: String
}
