//
//  ScoreKeeperApp.swift
//  ScoreKeeper
//
//  Created by Houénoukpo Johanu Gandonou on 09/01/2025.
//

import SwiftUI

@main
struct ScoreKeeperApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
