//
//  GameState.swift
//  ScoreKeeper
//
//
//


import Foundation


enum GameState {
    case setup
    case playing
    case gameOver
}

