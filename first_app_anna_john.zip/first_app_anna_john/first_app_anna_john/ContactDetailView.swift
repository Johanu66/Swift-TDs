//
//  ContactDetailView.swift
//  first_app_anna_john
//
//  Created by Houénoukpo Johanu Gandonou on 06/01/2025.
//

import SwiftUI

struct ContactDetailView: View {
    var contact: Contact
    var body: some View {
        VStack{
            Image(contact.image)
                .resizable()
                .frame(width: 250.0, height: 250.0)
                .clipShape(Circle())
                .shadow(radius: 10)
                .padding()
            Text(contact.firstName + " " + contact.lastName)
            Text(contact.number)
        }

    }
}

#Preview {
    ContactDetailView(contact: mesContacts[0])
}
