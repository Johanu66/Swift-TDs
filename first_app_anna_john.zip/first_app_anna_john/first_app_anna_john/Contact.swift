//
//  Contact.swift
//  first_app_anna_john
//
//  Created by Houénoukpo Johanu Gandonou on 06/01/2025.
//

import Foundation

struct Contact: Hashable {
    var id: Int
    var lastName:String
    var firstName : String
    var number : String
    var image : String
}
