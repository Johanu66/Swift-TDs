//
//  ContentView.swift
//  first_app_anna_john
//
//  Created by Houénoukpo Johanu Gandonou on 06/01/2025.
//

import SwiftUI

struct ContentView: View {
    @State private var face = 1
    var body: some View {
        NavigationView{
            //        VStack {
            //            Image(systemName: "die.face.\(face)")
            //                .imageScale(.large)
            //                .foregroundStyle(.tint)
            //            Text("This is a \(face)")
            //            Button("Roll") {
            //                /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/face = Int.random(in: 1...6)
            //            }
            //            .padding(20)
            //            .border(.blue)
            //        }
            //        .padding()
            //        .padding([.top, .bottom, .leading, .trailing], 20)
            //        .border(.blue)
            List(mesContacts, id: \.id){
                contact in NavigationLink(destination: ContactDetailView(contact: contact)){
                    ContactCellView(contact: contact)
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
