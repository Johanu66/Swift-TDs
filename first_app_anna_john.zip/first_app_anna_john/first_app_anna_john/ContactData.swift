//
//  ContactData.swift
//  first_app_anna_john
//
//  Created by Houénoukpo Johanu Gandonou on 06/01/2025.
//

import Foundation

var mesContacts = [
    Contact(id:1,lastName: "Meunier",firstName: "Charles",number: "0606060606",image: "meunier"),
    Contact(id:2,lastName: "Serier",firstName: "Karine",number: "0707070707",image: "serier"),
    Contact(id:3,lastName: "Heyrman",firstName: "Barthélémy",number: "0808080808",image: "heyrman")
]
