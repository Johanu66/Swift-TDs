//
//  ContactCellView.swift
//  first_app_anna_john
//
//  Created by Houénoukpo Johanu Gandonou on 06/01/2025.
//

import SwiftUI

struct ContactCellView: View {
    var contact : Contact
    var body: some View {
        HStack{
            Image(contact.image)
                .resizable()
                .frame(width: 50.0, height: 50.0)
                .padding()
            VStack{
                Text(contact.firstName)
                Text(contact.lastName)
            }
            Spacer()
            Text(contact.number)
        }.onSubmit {
            ContactDetailView(contact: contact)
        }
    }
}

#Preview {
    ContactCellView(contact: mesContacts[0])
}
