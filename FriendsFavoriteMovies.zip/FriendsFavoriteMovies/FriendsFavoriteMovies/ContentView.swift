//
//  ContentView.swift
//  FriendsFavoriteMovies
//
//
//


import SwiftUI


struct ContentView: View {
    var body: some View {
        TabView {
            FriendList()
                .tabItem {
                    Label("Friends", systemImage: "person.and.person")
            }

            MovieList()
                .tabItem {
                    Label("Movies", systemImage: "film.stack")
            }
        }
    }
}


#Preview {
    ContentView()
        .modelContainer(SampleData.shared.modelContainer)
}
